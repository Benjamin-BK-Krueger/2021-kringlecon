Well, this challenge is here to get you started. You will be guided through the KringleCon "onboarding process" step-by-step.
Just follow the steps presented to you:

1. Talk to Jingle Ringford - Jingle will start you on your journey!
2. Get your badge - Pick up your badge
3. Get the wifi adapter - Pick up the wifi adapter
4. Use the terminal - Click the computer terminal
```
The answer is already given:
Click in the upper pane of this terminal
Type answer and press Enter
```
Hint: If the screen is too busy because there a lot of players online, you can "hide" them in the settings, this way it's easier to find items/people/terminals
Hint: Some terminals are "split". You may have problems doing a copy&paste there. Enter "tmux set -g mouse off" in the termin windows to enable copy&paste for that moment