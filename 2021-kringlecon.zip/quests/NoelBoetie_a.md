Well, there is no real hint here than just to follow the rules, solve the equations and watch for the trolls ;)  
Stay away from the edges as well as the trolls are coming from there ;)